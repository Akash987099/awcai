@extends('layout.app')
@section('content')
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .product-header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1631&q=80');
            background-size: cover;
            background-position: center;
        }
        
        .feature-card {
            transition: transform 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .screenshot {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .price-tag {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
    </style>
</head>
<div class="py-8"></div>
    <!-- Header -->
    <header class="product-header text-white py-20">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row items-center">
                <div class="md:w-1/2 mb-10 md:mb-0">
                    <h1 class="text-4xl md:text-5xl font-bold mb-4">Funflix - Flutter OTT App Template</h1>
                    <p class="text-xl mb-6">Build your own streaming platform with this premium Flutter template</p>
                    <div class="flex items-center mb-6">
                        <div class="flex text-yellow-400 mr-4">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                        <span class="text-gray-300">4.7 (128 reviews)</span>
                    </div>
                    <div class="flex flex-wrap gap-2 mb-6">
                        <span class="bg-blue-500 bg-opacity-20 px-3 py-1 rounded-full text-sm">Flutter</span>
                        <span class="bg-purple-500 bg-opacity-20 px-3 py-1 rounded-full text-sm">OTT Platform</span>
                        <span class="bg-green-500 bg-opacity-20 px-3 py-1 rounded-full text-sm">Mobile App</span>
                        <span class="bg-red-500 bg-opacity-20 px-3 py-1 rounded-full text-sm">Firebase</span>
                    </div>
                    <div class="flex items-center">
                        <button class="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg mr-4 transition duration-300">
                            <i class="fas fa-shopping-cart mr-2"></i> Purchase Now - $49
                        </button>
                        <button class="border border-white hover:bg-white hover:bg-opacity-10 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                            <i class="far fa-eye mr-2"></i> Live Preview
                        </button>
                    </div>
                </div>
                <div class="md:w-1/2 flex justify-center">
                    <div class="relative">
                        <div class="absolute -top-6 -left-6 w-64 h-64 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
                        <div class="absolute -bottom-6 -right-6 w-64 h-64 bg-yellow-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
                        <div class="relative bg-white rounded-2xl shadow-2xl overflow-hidden w-80">
                            <img src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80" alt="Funflix App" class="w-full">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav class="bg-white shadow-sm sticky top-0 z-10">
        <div class="container mx-auto px-4">
            <div class="flex justify-center">
                <a href="#overview" class="py-4 px-6 text-gray-700 hover:text-purple-600 font-medium border-b-2 border-transparent hover:border-purple-600 transition duration-300">Overview</a>
                <a href="#features" class="py-4 px-6 text-gray-700 hover:text-purple-600 font-medium border-b-2 border-transparent hover:border-purple-600 transition duration-300">Features</a>
                <a href="#screenshots" class="py-4 px-6 text-gray-700 hover:text-purple-600 font-medium border-b-2 border-transparent hover:border-purple-600 transition duration-300">Screenshots</a>
                <a href="#documentation" class="py-4 px-6 text-gray-700 hover:text-purple-600 font-medium border-b-2 border-transparent hover:border-purple-600 transition duration-300">Documentation</a>
                <a href="#reviews" class="py-4 px-6 text-gray-700 hover:text-purple-600 font-medium border-b-2 border-transparent hover:border-purple-600 transition duration-300">Reviews</a>
                <a href="#support" class="py-4 px-6 text-gray-700 hover:text-purple-600 font-medium border-b-2 border-transparent hover:border-purple-600 transition duration-300">Support</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <!-- Overview Section -->
        <section id="overview" class="py-8 bg-white">
            <div class="container mx-auto px-4">
                <div class="flex flex-col md:flex-row items-center">
                    <div class="md:w-1/2 mb-10 md:mb-0">
                <h2 class="text-3xl md:text-4xl font-bold font-heading text-primary mb-4">About Funflix</h2>
           
                        <p class="text-lg mb-6 text-gray-700">
                            Funflix is a premium mobile app template built using Flutter, designed to serve as a starting point for building your own Over-The-Top (OTT) platform app. The template includes a comprehensive range of features such as movies and series listings, download functionality, user profiles, wishlists, and advanced security features to ensure user privacy and data protection.
                        </p>
                        <p class="text-lg mb-6 text-gray-700">
                            Built using Flutter, the template is highly customizable, making it easy to add new features or modify existing ones to fit your specific requirements. Whether you're building a Netflix clone, a specialized streaming service, or a video-on-demand platform, Funflix provides the foundation you need to get to market faster.
                        </p>
                        <div class="grid grid-cols-2 gap-6 mb-8">
                            <div class="bg-gray-50 p-5 rounded-lg border-l-4 border-purple-500">
                                <div class="text-2xl font-bold text-purple-600">5</div>
                                <div class="text-gray-600">Sales</div>
                            </div>
                            <div class="bg-gray-50 p-5 rounded-lg border-l-4 border-purple-500">
                                <div class="text-2xl font-bold text-purple-600">50+</div>
                                <div class="text-gray-600">Projects Delivered</div>
                            </div>
                            <div class="bg-gray-50 p-5 rounded-lg border-l-4 border-purple-500">
                                <div class="text-2xl font-bold text-purple-600">4.7/5</div>
                                <div class="text-gray-600">Rating</div>
                            </div>
                            <div class="bg-gray-50 p-5 rounded-lg border-l-4 border-purple-500">
                                <div class="text-2xl font-bold text-purple-600">24/7</div>
                                <div class="text-gray-600">Support</div>
                            </div>
                        </div>
                    </div>
                    <div class="md:w-1/2 md:pl-12">
                        <div class="bg-gradient-to-br from-purple-50 to-blue-50 p-8 rounded-2xl shadow-lg">
                            <h3 class="text-2xl font-bold mb-4">What's Included</h3>
                            <ul class="space-y-3">
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>Complete Flutter source code</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>Well-organized and documented code</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>Firebase backend integration</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>Android & iOS compatible</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>6 months of technical support</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>Free future updates</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                    <span>Lifetime usage license</span>
                                </li>
                            </ul>
                            <div class="mt-8 pt-6 border-t border-gray-200">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <span class="text-3xl font-bold text-gray-900">$49</span>
                                        <span class="text-gray-500 line-through ml-2">$99</span>
                                    </div>
                                    <button class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                                        <i class="fas fa-shopping-cart mr-2"></i> Buy Now
                                    </button>
                                </div>
                                <p class="text-sm text-gray-500 mt-2">Limited time offer. Price increases soon.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Features Section -->
        <section id="features" class="py-16 bg-gray-50">
            <div class="container mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="text-3xl font-bold mb-4">Key Features</h2>
                    <p class="text-lg text-gray-600 max-w-2xl mx-auto">Funflix comes packed with all the features you need to launch a successful streaming platform</p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div class="bg-white p-6 rounded-xl shadow-md feature-card">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                            <i class="fas fa-film text-purple-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-3">Movie & Series Library</h3>
                        <p class="text-gray-600">Organized catalog with categories, genres, and search functionality for easy content discovery.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md feature-card">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                            <i class="fas fa-download text-blue-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-3">Offline Viewing</h3>
                        <p class="text-gray-600">Download movies and episodes to watch later without an internet connection.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md feature-card">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                            <i class="fas fa-user text-green-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-3">User Profiles</h3>
                        <p class="text-gray-600">Multiple user profiles with personalized recommendations and watch history.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md feature-card">
                        <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                            <i class="fas fa-heart text-yellow-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-3">Wishlist & Favorites</h3>
                        <p class="text-gray-600">Save content to watch later and build personalized collections.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md feature-card">
                        <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                            <i class="fas fa-shield-alt text-red-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-3">Advanced Security</h3>
                        <p class="text-gray-600">Secure authentication and data protection to ensure user privacy.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md feature-card">
                        <div class="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                            <i class="fas fa-mobile-alt text-indigo-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-3">Cross-Platform</h3>
                        <p class="text-gray-600">Works seamlessly on both iOS and Android devices with native performance.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Screenshots Section -->
        <section id="screenshots" class="py-16 bg-white">
            <div class="container mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="text-3xl font-bold mb-4">App Screenshots</h2>
                    <p class="text-lg text-gray-600 max-w-2xl mx-auto">See how Funflix looks across different screens and features</p>
                </div>
                
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <div class="screenshot">
                        <img src="https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1631&q=80" alt="Home Screen" class="w-full h-auto">
                    </div>
                    <div class="screenshot">
                        <img src="https://images.unsplash.com/photo-1489599809505-f2d4cac355af?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Movie Details" class="w-full h-auto">
                    </div>
                    <div class="screenshot">
                        <img src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1450&q=80" alt="Search" class="w-full h-auto">
                    </div>
                    <div class="screenshot">
                        <img src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80" alt="Profile" class="w-full h-auto">
                    </div>
                </div>
            </div>
        </section>
    </main>


    <script>
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if(targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if(targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // Sticky navigation highlight
        window.addEventListener('scroll', function() {
            const sections = document.querySelectorAll('section');
            const navLinks = document.querySelectorAll('nav a');
            
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if(scrollY >= (sectionTop - 100)) {
                    current = section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('text-purple-600', 'border-purple-600');
                if(link.getAttribute('href').substring(1) === current) {
                    link.classList.add('text-purple-600', 'border-purple-600');
                }
            });
        });
    </script>
@endsection